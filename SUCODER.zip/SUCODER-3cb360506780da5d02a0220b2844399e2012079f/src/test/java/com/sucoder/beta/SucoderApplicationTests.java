package com.sucoder.beta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SucoderApplicationTests {

	@Test
	void contextLoads() {
	}

}
